﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Remote;
using NUnit.Framework;
using System.Collections.Generic;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System.Threading;

namespace NUnitSelenium
{
    [TestFixture("chrome", "128", "Windows 10")]
    [Parallelizable(ParallelScope.Children)]
    public class NUnitSeleniumSample
    {
        public static string LT_USERNAME = "ankitclambdatest";
        public static string LT_ACCESS_KEY = "aLUgd5KFYN0EdT2goOgehYni7amc56TGvV2km1OlZFBgQ21oJs";
        public static bool tunnel = Boolean.Parse(Environment.GetEnvironmentVariable("LT_TUNNEL") ?? "false");
        public static string build = "ankit";
        public static string seleniumUri = "https://hub.lambdatest.com:443/wd/hub";
        private const int GlobalTimeoutInSeconds = 100;

        private ThreadLocal<IWebDriver> driver = new ThreadLocal<IWebDriver>();
        private WebDriverWait wait;
        private string browser;
        private string version;
        private string os;

        public NUnitSeleniumSample(string browser, string version, string os)
        {
            this.browser = browser;
            this.version = version;
            this.os = os;
        }

        [SetUp]
        public void Init()
        {
            ChromeOptions capabilities = new ChromeOptions();
            Dictionary<string, object> ltOptions = new Dictionary<string, object>
            {
                { "username", LT_USERNAME },
                { "accessKey", LT_ACCESS_KEY },
                { "platformName", os },
                { "browserVersion", version },
                { "project", "Untitled" },
                { "selenium_version", "4.0.0" },
                { "w3c", true }
            };

            capabilities.AddAdditionalCapability("LT:Options", ltOptions, true);
            capabilities.AddArguments("--disable-web-security");
            capabilities.AddArguments("--allow-running-insecure-content");

            driver.Value = new RemoteWebDriver(new Uri(seleniumUri), capabilities.ToCapabilities(), TimeSpan.FromSeconds(GlobalTimeoutInSeconds));
            wait = new WebDriverWait(driver.Value, TimeSpan.FromSeconds(GlobalTimeoutInSeconds));

            Console.Out.WriteLine(driver);
        }

        [Test]
        public void Todotest()
        {
            try
            {
                Console.WriteLine("Navigating to todos app.");

                // Wait for the URL to load completely
                string expectedUrl = " https://httpbin.org/delay/100";
                driver.Value.Navigate().GoToUrl(expectedUrl);

                wait.Until(d => d.Url.Equals(expectedUrl, StringComparison.OrdinalIgnoreCase));
                Console.WriteLine("URL loaded successfully.");

                // Wait for elements before interacting
                var checkbox1 = wait.Until(ExpectedConditions.ElementToBeClickable(By.Name("li4")));
                checkbox1.Click();
                Console.WriteLine("Clicking Checkbox 1");

                var checkbox2 = wait.Until(ExpectedConditions.ElementToBeClickable(By.Name("li5")));
                checkbox2.Click();
                Console.WriteLine("Clicking Checkbox 2");

                // Verify both checkboxes clicked
                IList<IWebElement> elems = wait.Until(d => d.FindElements(By.ClassName("done-true")));
                Assert.AreEqual(2, elems.Count);

                Console.WriteLine("Entering Text");
                var inputField = wait.Until(ExpectedConditions.ElementIsVisible(By.Id("sampletodotext")));
                inputField.SendKeys("Yey, Let's add it to list");

                var addButton = wait.Until(ExpectedConditions.ElementToBeClickable(By.Id("addbutton")));
                addButton.Click();

                // Verify added item
                var addedText = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/div/div/div/ul/li[6]/span")));
                Assert.AreEqual("Yey, Let's add it to list", addedText.Text);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error during test execution: {ex.Message}");
                throw;
            }
        }

        [TearDown]
        public void Cleanup()
        {
            try
            {
                if (driver.Value != null)
                {
                    bool passed = TestContext.CurrentContext.Result.Outcome.Status == NUnit.Framework.Interfaces.TestStatus.Passed;
                    ((IJavaScriptExecutor)driver.Value).ExecuteScript("lambda-status=" + (passed ? "passed" : "failed"));
                    Console.WriteLine("Test executed: " + (passed ? "PASSED" : "FAILED"));
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error during cleanup: {ex.Message}");
            }
            finally
            {
                driver.Value?.Quit();
                driver.Value = null;
            }
        }
    }
}
